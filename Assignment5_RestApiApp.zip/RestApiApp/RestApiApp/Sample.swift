//
//  Sample.swift
//  RestApiApp
//
//  Created by admin on 03/02/25.
//

import SwiftUI

struct Sample: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Sample_Previews: PreviewProvider {
    static var previews: some View {
        Sample()
    }
}
