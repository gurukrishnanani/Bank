//
//  RestApiAppApp.swift
//  RestApiApp
//
//  Created by admin on 03/02/25.
//

import SwiftUI

@main
struct RestApiAppApp: App {
    var body: some Scene {
           WindowGroup {
               ContentView()
           }
       }
   }
